<?php
ob_start();
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
   <title>Hawki</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">    
    
    <!-- CSS files -->
    <link rel="stylesheet" type="text/css" href="resources/css/bootstrap.min.css" >
    <link rel="stylesheet" type="text/css" href="resources/css/bootstrap-responsive.min.css" >
    <link rel="stylesheet" type="text/css" href="resources/css/alveolae.css">
    <link rel="stylesheet" type="text/css" href="resources/css/font-awesome.css">
    <!-- Google font -->
    <link href="/css/css.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
function Validate(){
	var valid = true;
	var message = '';
	var fname = document.getElementById("SE_CODE");
	var lname = document.getElementById("RI_CODE");
	
	if(fname.value.trim() == ''){
		valid = false;
		message = message + '*SE code is required' + '\n';
	}
	if(lname.value.trim() == ''){
		valid = false;
		message = message + '*RI Code is required';
	}
	
	if (valid == false){
		alert(message);
		return false;
	}
}

  
</script>	
	<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->	
</head>

<body>
<style>

</style>
<!-- Navbar -->

	<!-- /Navbar -->
	<?php include 'header.php' ?>
	<form action="addJobHeirarchy.php" method="POST" onSubmit="return Validate();">
	<!-- Main content -->
	<div id="main-content">
		<!-- Container -->
		<div class="container">
			<!-- Header boxes -->
			<div class="box-container">
				
			</div>
			<!-- /Header boxes -->
			
            <div class="row">
				<!-- Sidebar -->				
				<!-- /Sidebar -->				
				<!-- Content -->
				<div class="span12 desktop">					
				    <div class="widget">                    					
					<div class="widget-content"> 
                                            <div class="span7">
                                            <h3>Job Heirarchy</h3>	
                                            </div>                       
                                <div class="span3">                                                                
	                               <div class="box-holder">
	                                
	                               </div>  
	                               <div class="box-holder">
								        
										 
	                               </div>  
                                      <div class="box-holder">
                                           <a href="jobHeirarchy.php">
                                           <div class="box"><img src="resources/images/e-close.png"/></br>Close</div></a>							
                                     </div>   
	                              	                              	                                              
	                            </div>                       
                    </div>                                    
                    </div>	              
                </div>
            </div>
				<div class="row">
                
				
				
				<!-- Content -->
					<div class="span12">	
						<div class="widget">
							<div class="widget-header">
								<h3>Add Job Heirarchy</h3>
							</div>
							<div class="widget-content">							   
                                <!-- <div class="span3"><label>Job Heirarchy Code</label><input type="text"  name="ID" disabled="disabled"  class="span3"></div>
                                <div class="span3"><label>Last Update Date</label><input type="text"  name="LAST_UPDATE_DATE" disabled="disabled"  class="span3"></div>-->
                                <div class="span4"><label>SE Code<font color="#FF0000"> *</font></label><input type="text" value="<?php echo !empty($SE_CODE)?$SE_CODE:'';?>" name="SE_CODE" id="SE_CODE"  class="span4"></div>
                                <div class="span4"><label>RI Code<font color="#FF0000"> *</font></label><input type="text" value="<?php echo !empty($RI_CODE)?$RI_CODE:'';?>" name="RI_CODE" id="RI_CODE" class="span4"></div>
                                    
                                   
                               	<div class="span3"><label>&nbsp;</label><input type="submit" name="Add" value="Add" class="btn btn-info span3" /></div>		
							</div>                
						</div>
					</div>
				<!-- /Content -->
                </div>
				<?php include 'footer.php' ?>
							<div class="dock-wrapper">    
									 <div class="navbar navbar-fixed-bottom">
										<div class="navbar-inner">
											<div class="container">                  
													<center>
														<div class="btn-group btn-group-justified">                      
															<a href="#" class="btn btn-default" onClick="newPage()">
															<img src="resources/images/d-add.png"/><br>New</a> 
															
															<a href="jobHeirarchy.php" class="btn btn-default">
															<img src="resources/images/e-close.png"/><br>Close</a>		
														</div>   
													</center> 	
											</div>     
										</div>
									</div>
							</div>		
				
				
        </div>
	</div>	
    </form>
	
</body>

</html>
<?php
			 require 'connection.php'; /** calling of connection.php that has the connection code **/
           
		 
			 if (! empty($_POST)){
			
		    	$SE_CODE = $_POST['SE_CODE'];
				$RI_CODE = $_POST['RI_CODE'];				
				
				     $valid = true;
                $pdo = Database::connect();
				$sql = "SELECT * FROM JOB_HIERARCHY WHERE SE_CODE = '$SE_CODE' OR RI_CODE = '$RI_CODE'";
				$query =  $pdo->prepare( $sql );
				$query->execute();
                $rows = $query->fetch(PDO::FETCH_NUM);
               if($rows > 0) {
                    	echo "<script language=javascript>alert('SE code  or RI code already exits.')</script>";
                 }
			  
		    else{
		            
		       $pdo = Database::connect();
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = "INSERT INTO JOB_HIERARCHY (LAST_UPDATE_DATE,SE_CODE,RI_CODE) values(now(), ?, ?)";
                $q = $pdo->prepare($sql);
                $q->execute(array($SE_CODE ,$RI_CODE));
                Database::disconnect();	
					echo "<div class='alert alert-info'> Successfully Inserted. </div>";
               	header('Location:jobHeirarchy.php');
				ob_end_flush();
                exit;
		    }
			    
			  	
			}
			ob_end_flush();
?>