<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
   <title>Hawki</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">    
    
    <!-- CSS files -->
    <link rel="stylesheet" type="text/css" href="resources/css/bootstrap.min.css" >
    <link rel="stylesheet" type="text/css" href="resources/css/bootstrap-responsive.min.css" >
    <link rel="stylesheet" type="text/css" href="resources/css/alveolae.css">
    <link rel="stylesheet" type="text/css" href="resources/css/font-awesome.css">
    <!-- Google font -->
    <link href="/css/css.css" rel="stylesheet" type="text/css">

	<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->	
</head>

<body>
<style>

</style>
<!-- Navbar -->
	<?php
			include 'connection.php'; /** calling of connection.php that has the connection code **/
			ob_start();
			$ID = $_GET['id']; /** get the EMP_TRACKER_SCH ID **/
			        $pdo = Database::connect();
					$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);			
					$result = $pdo->prepare("SELECT * FROM EMP_TRACKER_SCH WHERE id= :userid");
	                $result->bindParam(':userid', $ID);
	                $result->execute();
	                for($i=0; $row = $result->fetch(); $i++)
	{				Database::disconnect();	
			
		?>
	<!-- /Navbar -->
	<form action="" method="POST">
	<!-- Main content -->
	<div id="main-content">
		<!-- Container -->
		<div class="container">
			<!-- Header boxes -->
			<div class="box-container">
				
			</div>
			<!-- /Header boxes -->
			
                            <div class="row">
				<!-- Sidebar -->				
				<!-- /Sidebar -->				
				<!-- Content -->
				<div class="span12 desktop">					
				    <div class="widget">                    					
					<div class="widget-content"> 
                                            <div class="span7">
                                            <h3>Employee Track Scheduler Manger </h3>	
                                            </div>                       
                                               <div class="span3">                                                                
	                               <div class="box-holder">
	                                
	                               </div>  
	                               <div class="box-holder">
								        
										 
	                               </div>  
                                      <div class="box-holder">
                                           <a href="empTrackerScheduler.php">
                                           <div class="box"><img src="resources/images/e-close.png"/></br>Close</div></a>							
                                     </div>   
	                              	                              	                                              
	                             </div>                       
                                        </div>                                    
                                    </div>	              
                                </div>
                            </div>
				<div class="row">
                
				
				
				<!-- Content -->
					<div class="span12">	
						<div class="widget">
							<div class="widget-header">
								<h3>Edit Employee Tracker Scheduler</h3>
							</div>
							<div class="widget-content">							   
            <!-- <div class="span4"><label>Id</label><input type="text" value="<?php echo $row['ID'];?>" name="ID" disabled="disabled"  class="span4"></div>-->
            <div class="span4"><label>Employee Code</label><input type="text" value="<?php echo $row['EMP_ID'];?>" name="EMP_ID" disabled="disabled"  class="span4"></div>
            <div class="span4"><label>Last Update Date</label><input type="text" value="<?php echo $row['LAST_UPDATE_DATE'];?>" name="LAST_UPDATE_DATE" disabled="disabled"  class="span4"></div>
            <div class="span3"><label>&nbsp;</label><input type="submit" name="delete" value="Delete" class="btn btn-info span3" /></div>
            <div class="span4"><label>Sun Start Time</label><input type="text" value="<?php echo $row['SUN_STARTTIME'];?>" name="SUN_STARTTIME"  class="span4"></div>
            <div class="span4"><label>Sun End Time</label><input type="text" value="<?php echo $row['SUN_ENDTIME'];?>" name="SUN_ENDTIME"  class="span4"></div>
            <div class="span3"><label>Sun Time Interval</label><input type="text" value="<?php echo $row['SUN_TIMEINTERVAL'];?>" name="SUN_TIMEINTERVAL"  class="span3"></div>
            <div class="span4"><label>Mon Start Time</label><input type="text" value="<?php echo $row['MON_STARTTIME'];?>" name="MON_STARTTIME"  class="span4"></div>
            <div class="span4"><label>Mon End Time</label><input type="text" value="<?php echo $row['MON_ENDTIME'];?>" name="MON_ENDTIME"  class="span4"></div>
            <div class="span3"><label>Mon Time Interval</label><input type="text" value="<?php echo $row['MON_TIMEINTERVAL'];?>" name="MON_TIMEINTERVAL"  class="span3"></div>
            <div class="span4"><label>Tue Start Time</label><input type="text" value="<?php echo $row['TUE_STARTTIME'];?>" name="TUE_STARTTIME"  class="span4"></div>
            <div class="span4"><label>Tue End Time</label><input type="text" value="<?php echo $row['TUE_ENDTIME'];?>" name="TUE_ENDTIME"  class="span4"></div>
            <div class="span3"><label>Tue Time Interval</label><input type="text" value="<?php echo $row['TUE_TIMEINTERVAL'];?>" name="TUE_TIMEINTERVAL"  class="span3"></div>
            <div class="span4"><label>Wed Start Time</label><input type="text" value="<?php echo $row['WED_STARTTIME'];?>" name="WED_STARTTIME"  class="span4"></div>
            <div class="span4"><label>Wed End Time</label><input type="text" value="<?php echo $row['WED_ENDTIME'];?>" name="WED_ENDTIME"  class="span4"></div>
            <div class="span3"><label>Wed Time Interval</label><input type="text" value="<?php echo $row['WED_TIMEINTERVAL'];?>" name="WED_TIMEINTERVAL"  class="span3"></div>
            <div class="span4"><label>Thu Start Time</label><input type="text" value="<?php echo $row['THU_STARTTIME'];?>" name="THU_STARTTIME"  class="span4"></div>
            <div class="span4"><label>Thu End Time</label><input type="text" value="<?php echo $row['THU_ENDTIME'];?>" name="THU_ENDTIME"  class="span4"></div>
            <div class="span3"><label>Thu Time Interval</label><input type="text" value="<?php echo $row['THU_TIMEINTERVAL'];?>" name="THU_TIMEINTERVAL"  class="span3"></div>
            <div class="span4"><label>Fri Start Time</label><input type="text" value="<?php echo $row['FRI_STARTTIME'];?>" name="FRI_STARTTIME"  class="span4"></div>
            <div class="span4"><label>Fri End Time</label><input type="text" value="<?php echo $row['FRI_ENDTIME'];?>" name="FRI_ENDTIME"  class="span4"></div>
            <div class="span3"><label>Fri Time Interval</label><input type="text" value="<?php echo $row['FRI_TIMEINTERVAL'];?>" name="FRI_TIMEINTERVAL"  class="span3"></div>
            <div class="span4"><label>Sat Start Time</label><input type="text" value="<?php echo $row['SAT_STARTTIME'];?>" name="SAT_STARTTIME"  class="span4"></div>
            <div class="span4"><label>Sat End Time</label><input type="text" value="<?php echo $row['SAT_ENDTIME'];?>" name="SAT_ENDTIME"  class="span4"></div>
            <div class="span3"><label>Sat Time Interval</label><input type="text" value="<?php echo $row['SAT_TIMEINTERVAL'];?>" name="SAT_TIMEINTERVAL"  class="span3"></div>
           
            		
							</div>                
						</div>
					</div>
				<!-- /Content -->
                </div>
				<div id="footer">
				<hr>
				<p class="pull-right">Gaddiel Technologies Pvt Ltd &copy; 2013</p>
<div class="dock-wrapper">    
         <div class="navbar navbar-fixed-bottom">
            <div class="navbar-inner">
                <div class="container">                  
                        <center>
                            <div class="btn-group btn-group-justified">                      
							    <a href="#" class="btn btn-default" onClick="newPage()">
								<img src="resources/images/d-add.png"/><br>New</a> 
								<a id="viewd" class="viewd btn btn-default">
								<img src="resources/images/d-view.png"/><br>View</a>								   
								<a id="edit-d" href="#" class="edit-d btn btn-default">
								<img src="resources/images/d-edit.png"/><br>Edit</a>
							    <a href="controlPanel" class="btn btn-default">
								<img src="resources/images/d-trash.png"/><br>Delete</a>
							    <a href="controlPanel" class="btn btn-default">
									<img src="resources/images/e-close.png"/><br>Close</a>		
						    </div>   
						</center> 	
				</div>     
           	</div>
		</div>
     </div>		</div>
				
        </div>
</form>	
<?php
	}
?>	
</body>

</html>
<?php
// configuration
	// new data
	   if ( !empty($_POST)) {
	
			$ID =$_GET['id'];
			
			// query
			
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	
			$result = $pdo->prepare("DELETE FROM EMP_TRACKER_SCH WHERE ID= :memid");
	        $result->bindParam(':memid', $ID);	       
	        $result->execute();			
			header('Location:empTrackerScheduler.php');
			ob_end_flush();
            exit;
		}	
			
			
	
		
	
	
?>