<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
   <title>Hawki</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">    
    
    <!-- CSS files -->
    <link rel="stylesheet" type="text/css" href="resources/css/bootstrap.min.css" >
    <link rel="stylesheet" type="text/css" href="resources/css/bootstrap-responsive.min.css" >
    <link rel="stylesheet" type="text/css" href="resources/css/alveolae.css">
    <link rel="stylesheet" type="text/css" href="resources/css/font-awesome.css">
    <!-- Google font -->
    <link href="/css/css.css" rel="stylesheet" type="text/css">

	<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->	
</head>

<body>
<style>

</style>
<!-- Navbar -->

			<?php
			include 'connection.php'; /** calling of connection.php that has the connection code **/
			ob_start();
			$ID = $_GET['id']; /** get the EMP_DETAILS ID **/
			        $pdo = Database::connect();
					$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);			
					$result = $pdo->prepare("SELECT * FROM EMP_DETAILS WHERE id= :userid");
	                $result->bindParam(':userid', $ID);
	                $result->execute();
	                for($i=0; $row = $result->fetch(); $i++)
	{				Database::disconnect();	
			
		?>
	<!-- /Navbar -->
	<form action="" method="POST">
	<!-- Main content -->
	<div id="main-content">
		<!-- Container -->
		<div class="container">
			<!-- Header boxes -->
			<div class="box-container">
				
			</div>
			<!-- /Header boxes -->
			
                            <div class="row">
				<!-- Sidebar -->				
				<!-- /Sidebar -->				
				<!-- Content -->
				<div class="span12 desktop">					
				    <div class="widget">                    					
					<div class="widget-content"> 
                                            <div class="span7">
                                            <h3>Employee Manger </h3>	
                                            </div>                       
                                               <div class="span3">                                                                
	                               <div class="box-holder">
	                                
	                               </div>  
	                               <div class="box-holder">
								        
										 
	                               </div>  
                                      <div class="box-holder">
                                           <a href="employee.php">
                                           <div class="box"><img src="resources/images/e-close.png"/></br>Close</div></a>							
                                     </div>   
	                              	                              	                                              
	                             </div>                       
                                        </div>                                    
                                    </div>	              
                                </div>
                            </div>
				<div class="row">
                
				
				
				<!-- Content -->
					<div class="span12">	
						<div class="widget">
							<div class="widget-header">
								<h3>Edit Employee</h3>
							</div>
							<div class="widget-content">							   
								<div class="span3"><label>Employee ID</label><input type="text" value="<?php echo $row['ID'];?>" name="ID" disabled="disabled"  class="span3"></div>
								<div class="span3"><label>Employee Name</label><input type="text" value="<?php echo $row['EMP_NAME'];?>" name="EMP_NAME"  class="span3"></div>
								<div class="span3"><label>Email Id</label><input type="text" value="<?php echo $row['EMAIL_ID'];?>" name="EMAIL_ID"  class="span3"></div>
								<div class="span3"><label>Job Position</label><input type="text" value="<?php echo $row['JOB_POSITION'];?>" name="JOB_POSITION"  class="span3"></div>
								<div class="span3"><label>Job Code</label><input type="text" value="<?php echo $row['JOB_CODE'];?>" name="JOB_CODE" class="span3"></div>
								<div class="span3"><label>Mobile Num</label><input type="text" value="<?php echo $row['MOBILE_NUM'];?>" name="MOBILE_NUM"  class="span3"></div>
                                <div class="span3"><label>Device Active date</label><input type="text" value="<?php echo $row['DEVICE_ACTIVE_DATE'];?>" name="DEVICE_ACTIVE_DATE"  class="span3"></div>
                                <div class="span3"><label>Active</label><input type="text" value="<?php echo $row['ACTIVE'];?>" name="ACTIVE"  class="span3"></div>
                               
                               	<div class="span3"><label>&nbsp;</label><input type="submit" name="delete" value="Delete" class="btn btn-info span3" /></div>		
							</div>                
						</div>
					</div>
				<!-- /Content -->
                </div>
				<div id="footer">
				<hr>
				<p class="pull-right">Gaddiel Technologies Pvt Ltd &copy; 2013</p>
<div class="dock-wrapper">    
         <div class="navbar navbar-fixed-bottom">
            <div class="navbar-inner">
                <div class="container">                  
                        <center>
                            <div class="btn-group btn-group-justified">                      
							    <a href="#" class="btn btn-default" onClick="newPage()">
								<img src="resources/images/d-add.png"/><br>New</a> 
								<a id="viewd" class="viewd btn btn-default">
								<img src="resources/images/d-view.png"/><br>View</a>								   
								<a id="edit-d" href="#" class="edit-d btn btn-default">
								<img src="resources/images/d-edit.png"/><br>Edit</a>
							    <a href="controlPanel" class="btn btn-default">
								<img src="resources/images/d-trash.png"/><br>Delete</a>
							    <a href="controlPanel" class="btn btn-default">
									<img src="resources/images/e-close.png"/><br>Close</a>		
						    </div>   
						</center> 	
				</div>     
           	</div>
		</div>
     </div>		</div>
				
        </div>
</form>		
<?php
	}
?>	
</body>

</html>
<?php
// configuration
	// new data
	
	 if ( !empty($_POST)) {
		  
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	
			$result = $pdo->prepare("DELETE FROM EMP_DETAILS WHERE ID= :memid");
	        $result->bindParam(':memid', $ID);	       
	        $result->execute();			
			header('Location:employee.php');
			ob_end_flush();
            exit;
			
			
		}	
		
	
	
?>