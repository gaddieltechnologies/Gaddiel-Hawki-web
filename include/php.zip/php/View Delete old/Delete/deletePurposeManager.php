<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
   <title>Hawki</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">    
    
    <!-- CSS files -->
    <link rel="stylesheet" type="text/css" href="resources/css/bootstrap.min.css" >
    <link rel="stylesheet" type="text/css" href="resources/css/bootstrap-responsive.min.css" >
    <link rel="stylesheet" type="text/css" href="resources/css/alveolae.css">
    <link rel="stylesheet" type="text/css" href="resources/css/font-awesome.css">
    <!-- Google font -->
    <link href="/css/css.css" rel="stylesheet" type="text/css">

	<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->	
</head>
<script type=”text/javascript”>


</script>
<body>
<style>

</style>
<!-- Navbar -->
<?php
			include 'connection.php'; /** calling of connection.php that has the connection code **/
			ob_start();
			$ID = $_GET['id']; /** get the VISIT_PURPOSES ID **/
			        $pdo = Database::connect();
					$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);			
					$result = $pdo->prepare("SELECT * FROM VISIT_PURPOSES WHERE id= :userid");
	                $result->bindParam(':userid', $ID);
	                $result->execute();
	                for($i=0; $row = $result->fetch(); $i++)
	{				Database::disconnect();	
			
		?>
	<!-- /Navbar -->
	<form action="" method="POST">
	<!-- Main content -->
	<div id="main-content">
		<!-- Container -->
		<div class="container">
			<!-- Header boxes -->
			<div class="box-container">
				
			</div>
			<!-- /Header boxes -->
			
            <div class="row">
				<!-- Sidebar -->				
				<!-- /Sidebar -->				
				<!-- Content -->
				<div class="span12 desktop">					
				    <div class="widget">                    					
					<div class="widget-content"> 
                                            <div class="span7">
                                            <h3>Visit Purpose </h3>	
                                            </div>                       
                                               <div class="span3">                                                                
	                               <div class="box-holder">
	                                
	                               </div>  
	                               <div class="box-holder">
								        
										 
	                               </div>  
                                      <div class="box-holder">
                                           <a href="purposeManager.php">
                                           <div class="box"><img src="resources/images/e-close.png"/></br>Close</div></a>							
                                     </div>   
	                              	                              	                                              
	                             </div>                       
                                        </div>                                    
                                    </div>	              
                                </div>
            </div>
				<div class="row">
                
				
				
				<!-- Content -->
					<div class="span12">	
						<div class="widget">
							<div class="widget-header">
								<h3>Edit Visit Purpose</h3>
							</div>
							<div class="widget-content">							   
                                <div class="span3"><label>Purpose Code</label><input type="text" value="<?php echo $row['ID'];?>" name="id" disabled="disabled"  class="span3"></div>
                                <div class="span3"><label>Last Update date</label><input type="text" value="<?php echo $row['LAST_UPDATE_DATE']; ?>" name="LAST_UPDATE_DATE" disabled="disabled"  class="span3"></div>
                                <div class="span5"><label>Purpose Name</label><input type="text" value="<?php echo $row['PURPOSE_NAME']; ?>" name="PURPOSE_NAME"  class="span5"></div>
                                <div class="span8"><label>Description</label><input type="text" value="<?php echo $row['DESCRIPTION'];?>" name="DESCRIPTION"  class="span8"></div>
                                    
                                   
                               	<div class="span3"><label>&nbsp;</label><input type="submit" name="Delete" value="Delete" class="btn btn-info span3" /></div>		
							</div>                
						</div>
					</div>
				<!-- /Content -->
                </div>
				<div id="footer">
				<hr>
				<p class="pull-right">Gaddiel Technologies Pvt Ltd &copy; 2013</p>
<div class="dock-wrapper">    
         <div class="navbar navbar-fixed-bottom">
            <div class="navbar-inner">
                <div class="container">                  
                        <center>
                            <div class="btn-group btn-group-justified">                      
							    <a href="#" class="btn btn-default" onClick="newPage()">
								<img src="resources/images/d-add.png"/><br>New</a> 
								
							    <a href="purposeManager.php" class="btn btn-default">
								<img src="resources/images/e-close.png"/><br>Close</a>		
						    </div>   
						</center> 	
				</div>     
           	</div>
		</div>
     </div>		</div>
				
        </div>
</form>		
<?php
	}
?>
</body>

</html>

<?php
// configuration
	// new data
	
	 if ( !empty($_POST)) {
	
			$ID =$_GET['id'];
			
			// query
			
			$pdo = Database::connect();
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	
			$result = $pdo->prepare("DELETE FROM VISIT_PURPOSES WHERE ID= :memid");
	        $result->bindParam(':memid', $ID);	       
	        $result->execute();			
			header('Location:purposeManager.php');
			ob_end_flush();
            exit;
		}	
		
	
	
?>

