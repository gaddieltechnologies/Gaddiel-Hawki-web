<!-- saved from url=(0057)http://wbpreview.com/previews/WB01BG165/user-account.html -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	
    <title>Hawki</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">    
   
    <!-- CSS files -->
   <link rel="stylesheet" type="text/css" href="resources/css/bootstrap.min.css" >
    <link rel="stylesheet" type="text/css" href="resources/css/bootstrap.css" >
    <link rel="stylesheet" type="text/css" href="resources/css/bootstrap-responsive.min.css" >
    <link rel="stylesheet" type="text/css" href="resources/css/alveolae.css">
    <link rel="stylesheet" type="text/css" href="resources/css/font-awesome.css">
    <!-- Google font -->
   

	<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->	
</head>

<body>
	<!-- Navbar -->

<?php include 'header.php' ?>
	<!-- /Navbar -->
	
	<!-- Main content -->
	<div id="main-content">
		<!-- Container -->
		<div class="container">
			<!-- Header boxes -->
			<div class="box-container">
				
			</div>
			<!-- /Header boxes -->
			
		<div class="row">
				<!-- Sidebar -->
				
				<!-- /Sidebar -->
				
				<!-- Content -->
		<div class="span12">
			<h1 class="page-title desktop">Dash Board </h1>
				<div class="widget">						
					<div class="widget-content">
					<div class="box-container">
							
							<div class="box-holder">
                                <a href="clientCategory.php">
								<div class="box" style="height:60px;"></br>Client Category </div>
								</a>                            
							</div>							
							<div class="box-holder">						
                                <a href="clientClass.php">
								<div class="box" style="height:60px;"></br>Client Class </div>
                                </a>                            
							</div>  
							<div class="box-holder">						
								<a href="clientClassification.php">
								<div class="box" style="height:60px;"></br>Client Classification</div>
                                </a>							
							</div>
							

						</div> 
						<div class="box-container">
							
							<div class="box-holder">
                                <a href="purposeManager.php">
								<div class="box" style="height:60px;"></br>Visit Purpose Details</div>
								</a>                            
							</div>							
							<div class="box-holder">						
                                <a href="activity.php">
								<div class="box" style="height:60px;"></br>Visit Activity Details </div>
                                </a>                            
							</div>  
							<div class="box-holder">						
								<a href="visitSchedulePeriods.php">
								<div class="box" style="height:60px;"></br>Visit Schedule Periods</div>
                                </a>							
							</div>
							

						</div> 
						<div class="box-container">
							
							<div class="box-holder">
                                <a href="jobHeirarchy.php">
								<div class="box" style="height:60px;"></br>Job Heirarchy</div>
								</a>                            
							</div>							
							<div class="box-holder">						
                                <a href="employee.php">
								<div class="box" style="height:60px;"></br>Employee Details </div>
                                </a>                            
							</div>  
							<div class="box-holder">						
								<!--<a href="jobHeirarchy.php">-->
								<div class="box" style="height:60px;"></br></div>
                                </a>							
							</div>
							

						</div> 
					</div>
				</div>										
		</div>
				<!-- /Content -->
		</div>
			
			<!-- Footer -->
			<?php include 'footer.php' ?>
			<!-- /Footer -->
	
		</div>
		<!-- /Container -->
	</div>
	<!-- /Main content -->

	<!-- Javascript files -->
	


</body></html>