<?php
ob_start();
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
   <title>Hawki</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-capable" content="yes">    
    
    <!-- CSS files -->
    <link rel="stylesheet" type="text/css" href="resources/css/bootstrap.min.css" >
    <link rel="stylesheet" type="text/css" href="resources/css/bootstrap-responsive.min.css" >
    <link rel="stylesheet" type="text/css" href="resources/css/alveolae.css">
    <link rel="stylesheet" type="text/css" href="resources/css/font-awesome.css">
    <!-- Google font -->
    <link href="/css/css.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
function Validate(){
	var valid = true;
	var message = '';
	var EmployeeName = document.getElementById("EMP_NAME");
	var EmailId= document.getElementById("EMAIL_ID");
	var JobPosition = document.getElementById("JOB_POSITION");
	var JobCode= document.getElementById("JOB_CODE");
	var MobileNum = document.getElementById("MOBILE_NUM");
	var DeviceActive = document.getElementById("DEVICE_ACTIVE_DATE");
	var Active = document.getElementById("ACTIVE");
	//var lname = document.getElementById("RI_CODE");
	
	if( EmployeeName.value.trim() == ''){
		valid = false;
		message = message + '*Employee Name is required' + '\n';
	}
	if(EmailId.value.trim() == ''){
		valid = false;
		message = message + '*Email Id is required' + '\n';
	}
	if(JobPosition.value.trim() == ''){
		valid = false;
		message = message + '*Job Position is required' + '\n';
	}
	if(JobCode.value.trim() == ''){
		valid = false;
		message = message + '*Job Code is required' + '\n';
	}
	if(MobileNum.value.trim() == ''){
		valid = false;
		message = message + '*Mobile Number is required' + '\n';
	}
	if(DeviceActive.value.trim() == ''){
		valid = false;
		message = message + '*Device Active Date is required' + '\n';
	}
	if(Active.value.trim() == ''){
		valid = false;
		message = message + '*Active is required' + '\n';
	}
	if (valid == false){
		alert(message);
		return false;
	}
}

  
</script>
	<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->	
</head>

<body>
<style>

</style>
<!-- Navbar -->
    <?php include 'header.php' ?>
	<!-- /Navbar -->
	<form action="addEmployee.php" method="POST"  onSubmit="return Validate();">
	<!-- Main content -->
	<div id="main-content">
		<!-- Container -->
		<div class="container">
			<!-- Header boxes -->
			<div class="box-container">
				
			</div>
			<!-- /Header boxes -->
			
                <div class="row">
				<!-- Sidebar -->				
				<!-- /Sidebar -->				
				<!-- Content -->
						<div class="span12 desktop">					
							<div class="widget">                    					
							<div class="widget-content"> 
								<div class="span7">
									<h3>Employee Details </h3>	
								</div>                       
								<div class="span3">                                                                
									<div class="box-holder">
											
									</div>  
									<div class="box-holder">
												
												 
									</div>  
									<div class="box-holder">
										<a href="employee.php">
										<div class="box"><img src="resources/images/e-close.png"/></br>Close</div></a>							
									</div>   
																														  
								</div>                       
							</div>                                    
							</div>	              
						</div>
                </div>
				<div class="row">
                
				
				
				<!-- Content -->
					<div class="span12">	
						<div class="widget">
							<div class="widget-header">
								<h3>Add Employee</h3>
							</div>
							<div class="widget-content">							                              
                                 <div class="span3"><label>Code</label><input type="text" name="ID" disabled="disabled"  class="span3"></div>
								<div class="span3"><label>Employee Name<font color="#FF0000"> *</font></label><input type="text" value="<?php echo !empty($EMP_NAME)?$EMP_NAME:'';?>" name="EMP_NAME"  id="EMP_NAME" class="span3"></div>
								<div class="span3"><label>Email Id<font color="#FF0000"> *</font></label><input type="text" value="<?php echo !empty($EMAIL_ID)?$EMAIL_ID:'';?>" name="EMAIL_ID"  id="EMAIL_ID" class="span3"></div>
								<div class="span3"><label>Job Position<font color="#FF0000"> *</font></label><input type="text" value="<?php echo !empty($JOB_POSITION)?$JOB_POSITION:'';?>" name="JOB_POSITION" id="JOB_POSITION" class="span3"></div>
								<div class="span3"><label>Job Code<font color="#FF0000"> *</font></label><input type="text" value="<?php echo !empty($JOB_CODE)?$JOB_CODE:'';?>" name="JOB_CODE" id="JOB_CODE" class="span3"></div>
								<div class="span3"><label>Mobile Num<font color="#FF0000"> *</font></label><input type="text" value="<?php echo !empty($MOBILE_NUM)?$MOBILE_NUM:'';?>" name="MOBILE_NUM" id="MOBILE_NUM" class="span3"></div>
                                <div class="span3"><label>Device Active Date</label><input type="text" value="<?php echo !empty($DEVICE_ACTIVE_DATE)?$DEVICE_ACTIVE_DATE:'';?>" name="DEVICE_ACTIVE_DATE" id="DEVICE_ACTIVE_DATE" class="span3"></div>
                                <div class="span3"><label>Active<font color="#FF0000"> *</font></label><input type="text" value="<?php echo !empty($ACTIVE)?$ACTIVE:'';?>" name="ACTIVE" id="ACTIVE"  class="span3"></div>   
                                   
                               	<div class="span3"><label>&nbsp;</label><input type="submit" name="Add" value="Add" class="btn btn-info span3" /></div>		
							</div>                
						</div>
					</div>
				<!-- /Content -->
                </div>
				<?php include 'footer.php' ?>
					<div class="dock-wrapper">    
							 <div class="navbar navbar-fixed-bottom">
								<div class="navbar-inner">
									<div class="container">                  
											<center>
												<div class="btn-group btn-group-justified">                      
													<a href="#" class="btn btn-default" onClick="newPage()">
													<img src="resources/images/d-add.png"/><br>New</a> 
													
													<a href="employee.php" class="btn btn-default">
													<img src="resources/images/e-close.png"/><br>Close</a>		
												</div>   
											</center> 	
									</div>     
								</div>
							</div>
					</div>		
				
				
        </div>
	</div>	
    </form>		
</body>

</html>
<?php
			 require 'connection.php'; /** calling of connection.php that has the connection code **/
           
		    if ( !empty($_POST))
			{
		    	
				$EMP_NAME = $_POST['EMP_NAME'];
			    $EMAIL_ID = $_POST['EMAIL_ID'];
			    $JOB_POSITION = $_POST['JOB_POSITION'];
			    $JOB_CODE = $_POST['JOB_CODE'];
			    $MOBILE_NUM = $_POST['MOBILE_NUM'];
			    $DEVICE_ACTIVE_DATE = $_POST['DEVICE_ACTIVE_DATE'];
			    $ACTIVE = $_POST['ACTIVE'];
			
			     $valid = true;
                $pdo = Database::connect();
				$sql = "SELECT * FROM EMP_DETAILS WHERE EMAIL_ID = '$EMAIL_ID'";
				$query =  $pdo->prepare( $sql );
				$query->execute();
                $rows = $query->fetch(PDO::FETCH_NUM);
               if($rows > 0) {
                    	echo "<script language=javascript>alert('Email ID already exits.')</script>";
                 }
			  
		    else{
				$pdo = Database::connect();
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = "INSERT INTO EMP_DETAILS (EMP_NAME,EMAIL_ID,JOB_POSITION,JOB_CODE,MOBILE_NUM,DEVICE_ACTIVE_DATE,ACTIVE) values(?, ?, ?,?, ?, ?,?)";
                $q = $pdo->prepare($sql);
                $q->execute(array($EMP_NAME ,$EMAIL_ID,$JOB_POSITION ,$JOB_CODE,$MOBILE_NUM ,$DEVICE_ACTIVE_DATE,$ACTIVE));
                Database::disconnect();	
				echo "<div class='alert alert-info'> Successfully Inserted. </div>";
               	header('Location:employee.php');
				ob_end_flush();
                 exit;
		    }
			    
			  	
			}
			ob_end_flush();
		?>