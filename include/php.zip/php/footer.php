<!-- Footer -->
			<div id="footer">
				<hr>
				<p class="pull-right"><a href="http://www.gaddieltech.com" >Gaddiel Technologies Pvt Ltd </a> &copy; 2014</p>
			</div>
			
			<!-- /Footer -->