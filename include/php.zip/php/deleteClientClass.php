<?php 
include "connection2.php"; /** calling of connection.php that has the connection code **/ 

$id = $_GET['id'];

mysql_query("DELETE FROM CLIENT_CLASS WHERE ID=$id");

			header('Location:clientClass.php');
	
?>

