<?php
	mysql_connect('gaddieltech.fatcowmysql.com','jpbsrmsys','c@v@22July14'); /** Syntax ==> mysql_connect(SERVERNAME,USERNAME,PASSWORD); **/
	
	mysql_select_db('jpb_hawki'); /** This will select the databasename **/
	
