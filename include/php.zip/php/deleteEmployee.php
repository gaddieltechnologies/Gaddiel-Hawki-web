<?php 
include "connection2.php"; /** calling of connection.php that has the connection code **/ 

$id = $_GET['id'];

mysql_query("DELETE FROM EMP_DETAILS WHERE ID= $id");

			header('Location: employee.php');
	
?>
