<?php
	mysql_connect('localhost','root',''); /** Syntax ==> mysql_connect(SERVERNAME,USERNAME,PASSWORD); **/
	
	mysql_select_db('jpb_hawki'); /** This will select the databasename **/