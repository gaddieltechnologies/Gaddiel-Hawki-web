	<!-- Navbar -->
	<div class="navbar navbar-fixed-top">
		<div class="navbar-inner">
			<div class="container">
				<a class="brand" href="#">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="jindal.png" width="60px"/>&nbsp;&nbsp;JINDAL POLYBUTTONS LTD</a>
				<div class="nav-collapse">
					<ul class="nav pull-right">
					 <li class="divider-vertical"></li>
					 <li><a href="index.php"><i class="icon-lock"></i>&nbsp;&nbsp;Logout</a></li>
					 <li class="divider-vertical"></li>
					</ul>
				</div>
			</div>
		</div>

	</div>
	<!-- /Navbar -->